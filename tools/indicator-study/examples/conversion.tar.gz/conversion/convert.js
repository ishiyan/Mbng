const fs = require('fs');

// Read the file
const content = fs.readFileSync('test-data-ohlcv.ts', 'utf-8');

// Extract the array content
const arrayStart = content.indexOf('[');
const arrayEnd = content.lastIndexOf('];');

if (arrayStart === -1 || arrayEnd === -1) {
  console.error('Could not find array boundaries');
  process.exit(1);
}

const arrayStr = content.substring(arrayStart + 1, arrayEnd);

// Parse entries using regex
const entries = [];
const pattern = /\{\s*time:\s*new Date\((\d+),\s*(\d+),\s*(\d+)\),\s*open:\s*([\d.]+),\s*high:\s*([\d.]+),\s*low:\s*([\d.]+),\s*close:\s*([\d.]+),\s*volume:\s*(\d+)\s*\}/g;

let match;
while ((match = pattern.exec(arrayStr)) !== null) {
  const year = parseInt(match[1]);
  const month = parseInt(match[2]);
  const day = parseInt(match[3]);
  const date = new Date(Date.UTC(year, month, day));
  
  entries.push({
    time: date.toISOString(),
    open: parseFloat(match[4]),
    high: parseFloat(match[5]),
    low: parseFloat(match[6]),
    close: parseFloat(match[7]),
    volume: parseInt(match[8])
  });
}

console.log(`Parsed ${entries.length} entries`);

if (entries.length === 0) {
  console.error('No entries parsed!');
  process.exit(1);
}

// Get header and footer
const header = content.substring(0, arrayStart);
const footer = content.substring(arrayEnd + 2);

// Create new content
const newContent = header + JSON.stringify(entries, null, 2) + footer;

// Write back
fs.writeFileSync('test-data-ohlcv.ts', newContent);
console.log('✓ File converted successfully!');
