const fs = require('fs');

// Read the file
const content = fs.readFileSync('test-data-bb-up.ts', 'utf-8');

// Extract the array content
const arrayStart = content.indexOf('[');
const arrayEnd = content.lastIndexOf('];');

if (arrayStart === -1 || arrayEnd === -1) {
  console.error('Could not find array boundaries');
  process.exit(1);
}

const arrayStr = content.substring(arrayStart + 1, arrayEnd);

// Parse entries using regex
const entries = [];
const pattern = /\{\s*time:\s*new Date\((\d+),\s*(\d+),\s*(\d+)\),\s*value:\s*(NaN|[\d.eE+-]+)\s*\}/g;

let match;
while ((match = pattern.exec(arrayStr)) !== null) {
  const year = parseInt(match[1]);
  const month = parseInt(match[2]);
  const day = parseInt(match[3]);
  const date = new Date(Date.UTC(year, month, day));
  const value = match[4] === 'NaN' ? null : parseFloat(match[4]);
  
  entries.push({
    time: date.toISOString(),
    value: value
  });
}

console.log(`Parsed ${entries.length} entries`);

if (entries.length === 0) {
  console.error('No entries parsed!');
  process.exit(1);
}

// Get header and footer
const header = content.substring(0, arrayStart);
const footer = content.substring(arrayEnd + 2);

// Create new content
const newContent = header + JSON.stringify(entries, null, 2) + footer;

// Write back
fs.writeFileSync('test-data-bb-up.ts', newContent);
console.log('✓ File converted successfully!');
