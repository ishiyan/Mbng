const fs = require('fs');
const path = require('path');

const files = ['a1.ts', 'a10.ts'];

files.forEach(file => {
  const filePath = path.join(__dirname, file);
  const content = fs.readFileSync(filePath, 'utf8');

  // Match each object entry
  const entryPattern = /\{\s*time:\s*new Date\((\d+),\s*(\d+),\s*(\d+)\),\s*parameterFirst:\s*(NaN|[\d.eE+-]+),\s*parameterLast:\s*(NaN|[\d.eE+-]+),\s*parameterResolution:\s*(NaN|[\d.eE+-]+),\s*valueMin:\s*(NaN|[\d.eE+-]+),\s*valueMax:\s*(NaN|[\d.eE+-]+),\s*values:\s*\[([\s\S]*?)\]\s*\}/g;

  let match;
  const entries = [];

  while ((match = entryPattern.exec(content)) !== null) {
    const year = parseInt(match[1], 10);
    const month = parseInt(match[2], 10);
    const day = parseInt(match[3], 10);
    const parameterFirst = match[4] === 'NaN' ? null : parseFloat(match[4]);
    const parameterLast = match[5] === 'NaN' ? null : parseFloat(match[5]);
    const parameterResolution = match[6] === 'NaN' ? null : parseFloat(match[6]);
    const valueMin = match[7] === 'NaN' ? null : parseFloat(match[7]);
    const valueMax = match[8] === 'NaN' ? null : parseFloat(match[8]);

    // Parse values array
    const valuesStr = match[9].trim();
    let values = [];
    if (valuesStr.length > 0) {
      values = valuesStr.split(/\s*,\s*/).map(v => {
        v = v.trim();
        if (v === 'NaN') return null;
        return parseFloat(v);
      });
    }

    const date = new Date(Date.UTC(year, month, day));

    entries.push({
      time: date.toISOString(),
      parameterFirst,
      parameterLast,
      parameterResolution,
      valueMin,
      valueMax,
      values
    });
  }

  const output = { testDataGoertzel: entries };
  const outputFile = file.replace('.ts', '.json');
  fs.writeFileSync(path.join(__dirname, outputFile), JSON.stringify(output, null, 2));
  console.log(`${file} -> ${outputFile}: ${entries.length} entries`);
});
