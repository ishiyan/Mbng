const fs = require('fs');
const path = require('path');

const files = ['test-data-bb.json'];

files.forEach(file => {
  const filePath = path.join(__dirname, file);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

  let output = '{\n  "data": [\n';
  const entries = data.data;
  for (let i = 0; i < entries.length; i++) {
    output += '    ' + JSON.stringify(entries[i]);
    if (i < entries.length - 1) output += ',';
    output += '\n';
  }
  output += '  ]\n}\n';

  fs.writeFileSync(filePath, output);
  console.log(`${file}: compacted ${entries.length} entries to one line each`);
});
