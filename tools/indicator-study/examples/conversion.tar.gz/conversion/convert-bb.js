const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'test-data-bb.ts');
const content = fs.readFileSync(filePath, 'utf8');

// Extract header and footer
const arrayStart = content.indexOf('[');
const arrayEnd = content.lastIndexOf(']');

if (arrayStart === -1 || arrayEnd === -1) {
  console.error('Could not find array boundaries');
  process.exit(1);
}

const header = content.substring(0, arrayStart + 1);
const footer = content.substring(arrayEnd);
const arrayContent = content.substring(arrayStart + 1, arrayEnd);

// Regex pattern for Band entries: { time: new Date(year, month, day), lower: value, upper: value }
const bandPattern = /\{\s*time:\s*new Date\((\d+),\s*(\d+),\s*(\d+)\),\s*lower:\s*(NaN|[\d.eE+-]+),\s*upper:\s*(NaN|[\d.eE+-]+)\s*\}/g;

let match;
let entries = [];
let entryCount = 0;

while ((match = bandPattern.exec(arrayContent)) !== null) {
  const year = parseInt(match[1], 10);
  const month = parseInt(match[2], 10);
  const day = parseInt(match[3], 10);
  const lower = match[4] === 'NaN' ? null : parseFloat(match[4]);
  const upper = match[5] === 'NaN' ? null : parseFloat(match[5]);

  const date = new Date(Date.UTC(year, month, day));
  const isoDate = date.toISOString();

  entries.push({
    time: isoDate,
    lower: lower,
    upper: upper
  });

  entryCount++;
}

console.log(`Parsed ${entryCount} entries`);

if (entryCount === 0) {
  console.error('No entries matched the pattern');
  process.exit(1);
}

// Convert to JSON format with proper indentation
const jsonArray = JSON.stringify(entries, null, 2);

// Write back to file
const newContent = header + '\n' + jsonArray + '\n' + footer;
fs.writeFileSync(filePath, newContent, 'utf8');

console.log('✓ File converted successfully!');
