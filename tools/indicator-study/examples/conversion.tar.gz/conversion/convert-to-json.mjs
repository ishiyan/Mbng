import fs from 'fs';

// Read the current TS file
const tsContent = fs.readFileSync('test-data-ohlcv.ts', 'utf-8');

// Create a temporary function to define testDataOhlcv
let testDataOhlcv;
eval(tsContent.replace('export const', 'const'));

// Convert each entry's time from Date object to ISO string
const convertedData = testDataOhlcv.map(item => ({
  time: item.time.toISOString(),
  open: item.open,
  high: item.high,
  low: item.low,
  close: item.close,
  volume: item.volume
}));

// Create the new TS file content with JSON data
const newTsContent = `import { Ohlcv } from 'projects/mb/src/lib/data/entities/ohlcv';

/** Source data used to generate output for indicators. */
export const testDataOhlcv: Ohlcv[] = ${JSON.stringify(convertedData, null, 2)};
`;

// Write back to the file
fs.writeFileSync('test-data-ohlcv.ts', newTsContent);
console.log('Conversion complete! File updated with JSON format.');
