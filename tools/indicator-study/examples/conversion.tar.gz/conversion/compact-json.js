const fs = require('fs');
const path = require('path');

const files = ['a1.json', 'a10.json'];

files.forEach(file => {
  const filePath = path.join(__dirname, file);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

  let output = '{\n  "testDataGoertzel": [\n';
  const entries = data.testDataGoertzel;
  for (let i = 0; i < entries.length; i++) {
    output += '    ' + JSON.stringify(entries[i]);
    if (i < entries.length - 1) output += ',';
    output += '\n';
  }
  output += '  ]\n}\n';

  fs.writeFileSync(filePath, output);
  console.log(`${file}: compacted ${entries.length} entries to one line each`);
});
