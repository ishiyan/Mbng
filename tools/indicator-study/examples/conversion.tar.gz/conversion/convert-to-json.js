const fs = require('fs');

// Read the current TS file
const tsContent = fs.readFileSync('test-data-ohlcv.ts', 'utf-8');

// Extract everything between [ and ];
const startIndex = tsContent.indexOf('[');
const endIndex = tsContent.lastIndexOf(']');
const arrayStr = tsContent.substring(startIndex + 1, endIndex);

// Split by comma but be careful with nested structures
// Parse each object manually
const objectPattern = /\{\s*time:\s*new Date\((\d+),\s*(\d+),\s*(\d+)\),\s*open:\s*([\d.]+),\s*high:\s*([\d.]+),\s*low:\s*([\d.]+),\s*close:\s*([\d.]+),\s*volume:\s*(\d+)\s*\}/g;

const data = [];
let match;
while ((match = objectPattern.exec(arrayStr)) !== null) {
  const year = parseInt(match[1]);
  const month = parseInt(match[2]);
  const day = parseInt(match[3]);
  const date = new Date(Date.UTC(year, month, day));
  
  data.push({
    time: date.toISOString(),
    open: parseFloat(match[4]),
    high: parseFloat(match[5]),
    low: parseFloat(match[6]),
    close: parseFloat(match[7]),
    volume: parseInt(match[8])
  });
}

console.log(`Parsed ${data.length} data points`);

// Create the new TS file content
const newContent = `import { Ohlcv } from 'projects/mb/src/lib/data/entities/ohlcv';

/** Source data used to generate output for indicators. */
export const testDataOhlcv: Ohlcv[] = ${JSON.stringify(data, null, 2)};
`;

// Write the file
fs.writeFileSync('test-data-ohlcv.ts', newContent);
console.log('File successfully converted to JSON format!');
