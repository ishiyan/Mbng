import { Scalar } from '../../../data/entities/scalar';

export class IndicatorHorizontal {
  data!: Scalar[];
  value!: number;
  line: any;
  path: any;
}
