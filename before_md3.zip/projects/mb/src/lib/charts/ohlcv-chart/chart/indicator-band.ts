import { Band } from '../../entities/band';

export class IndicatorBand {
  data!: Band[];
  area: any;
  path: any;
}
