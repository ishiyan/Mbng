import { Scalar } from '../../../data/entities/scalar';

export class IndicatorLineArea {
  data!: Scalar[];
  value!: number;
  area: any;
  path: any;
}
