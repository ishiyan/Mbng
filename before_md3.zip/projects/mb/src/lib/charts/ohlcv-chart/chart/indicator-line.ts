import { Scalar } from '../../../data/entities/scalar';

export class IndicatorLine {
  data!: Scalar[];
  line: any;
  path: any;
}
