export class HorizontalLayoutBlock {
  public left = 0;
  public width = 0;
}
