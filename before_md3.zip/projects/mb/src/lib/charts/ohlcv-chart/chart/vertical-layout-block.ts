export class VerticalLayoutBlock {
  public top = 0;
  public height = 0;
}
