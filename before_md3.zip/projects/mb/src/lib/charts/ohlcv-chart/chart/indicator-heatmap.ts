import { Heatmap } from '../../entities/heatmap';

export class IndicatorHeatmap {
  data!: Heatmap[];
  gradient: any;
  invertGradient!: boolean;
  path: any;
  height!: number;
}
