/** The margins of the chart, exclusive space needed for annotation. */
export class Margin {
  public left = 0;
  public top = 0;
  public right = 0;
  public bottom = 0;
}
