import { arrow as _arrow } from './arrow';

export const shapes = {
  arrow: _arrow
};
