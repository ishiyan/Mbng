export interface HierarchyTreeNode {
  value?: number;
  name?: string;
  children?: HierarchyTreeNode[];
}
