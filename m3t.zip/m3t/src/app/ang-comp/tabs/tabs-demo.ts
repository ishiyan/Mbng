/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

import {ChangeDetectionStrategy, Component} from '@angular/core';
import {MatTabsModule} from '@angular/material/tabs';

import {TabGroupAlignExample} from './tab-group-align/tab-group-align-example';
import {TabGroupAnimationsExample} from './tab-group-animations/tab-group-animations-example';
import {TabGroupAsyncExample} from './tab-group-async/tab-group-async-example';
import {TabGroupBasicExample} from './tab-group-basic/tab-group-basic-example';
import {TabGroupCustomLabelExample} from './tab-group-custom-label/tab-group-custom-label-example';
import {TabGroupDynamicExample} from './tab-group-dynamic/tab-group-dynamic-example';
import {TabGroupDynamicHeightExample} from './tab-group-dynamic-height/tab-group-dynamic-height-example';
import {TabGroupHeaderBelowExample} from './tab-group-header-below/tab-group-header-below-example';
import {TabGroupInkBarExample} from './tab-group-ink-bar/tab-group-ink-bar-example';
import {TabGroupLazyLoadedExample} from './tab-group-lazy-loaded/tab-group-lazy-loaded-example';
import {TabGroupPaginatedExample} from './tab-group-paginated/tab-group-paginated-example';
import {TabGroupStretchedExample} from './tab-group-stretched/tab-group-stretched-example';
import {TabNavBarBasicExample} from './tab-nav-bar-basic/tab-nav-bar-basic-example';

@Component({
  selector: 'tabs-demo',
  templateUrl: 'tabs-demo.html',
  imports: [
    TabGroupInkBarExample,
    TabGroupPaginatedExample,
    TabNavBarBasicExample,
    TabGroupStretchedExample,
    TabGroupLazyLoadedExample,
    TabGroupHeaderBelowExample,
    TabGroupDynamicExample,
    TabGroupAlignExample,
    TabGroupAnimationsExample,
    TabGroupAsyncExample,
    TabGroupBasicExample,
    TabGroupCustomLabelExample,
    TabGroupDynamicHeightExample,
    MatTabsModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TabsDemo {}
