/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

import {CdkMenuModule} from '@angular/cdk/menu';
import {ConnectedPosition} from '@angular/cdk/overlay';
import {ChangeDetectionStrategy, Component} from '@angular/core';

import {CdkMenuContextExample} from './cdk-menu-context/cdk-menu-context-example';
import {CdkMenuInlineExample} from './cdk-menu-inline/cdk-menu-inline-example';
import {CdkMenuMenubarExample} from './cdk-menu-menubar/cdk-menu-menubar-example';
import {CdkMenuNestedContextExample} from './cdk-menu-nested-context/cdk-menu-nested-context-example';
import {CdkMenuStandaloneMenuExample} from './cdk-menu-standalone-menu/cdk-menu-standalone-menu-example';
import {CdkMenuStandaloneStatefulMenuExample} from './cdk-menu-standalone-stateful-menu/cdk-menu-standalone-stateful-menu-example';

@Component({
  templateUrl: 'cdk-menu-demo.html',
  styleUrl: 'cdk-menu-demo.css',
  imports: [
    CdkMenuModule,
    CdkMenuStandaloneMenuExample,
    CdkMenuStandaloneStatefulMenuExample,
    CdkMenuMenubarExample,
    CdkMenuInlineExample,
    CdkMenuContextExample,
    CdkMenuNestedContextExample,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CdkMenuDemo {
  customPosition = [
    {originX: 'center', originY: 'center', overlayX: 'center', overlayY: 'center'},
  ] as ConnectedPosition[];

  sizes = ['Small', 'Normal', 'Large'];
  colors = ['Red', 'Green', 'Blue'];
  selectedSize: string | undefined = 'Normal';
  selectedColor: string | undefined = 'Red';
}
