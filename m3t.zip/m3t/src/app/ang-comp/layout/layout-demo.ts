/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

import {ChangeDetectionStrategy, Component} from '@angular/core';

import {BreakpointObserverOverviewExample} from './breakpoint-observer-overview/breakpoint-observer-overview-example';

@Component({
  selector: 'layout-demo',
  templateUrl: 'layout-demo.html',
  styleUrl: 'layout-demo.scss',
  imports: [BreakpointObserverOverviewExample],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LayoutDemo {}
