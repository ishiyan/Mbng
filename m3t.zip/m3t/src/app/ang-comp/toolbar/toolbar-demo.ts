/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */

import {ChangeDetectionStrategy, Component} from '@angular/core';
import {MatButtonModule} from '@angular/material/button';
import {MatIconModule} from '@angular/material/icon';
import {MatToolbarModule} from '@angular/material/toolbar';

import {ToolbarSimpleExample} from './toolbar-simple/toolbar-simple-example';
import {ToolbarOverviewExample} from './toolbar-overview/toolbar-overview-example';

@Component({
  selector: 'toolbar-demo',
  templateUrl: 'toolbar-demo.html',
  styleUrl: 'toolbar-demo.scss',
  imports: [
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    ToolbarOverviewExample,
    ToolbarSimpleExample,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ToolbarDemo {}
