import {ChangeDetectionStrategy, Component, inject} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import {MatSlideToggleChange, MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatButtonToggleModule} from '@angular/material/button-toggle';

import {DarkLight, DarkLightColorSchemeService} from './dark-light-color-scheme.service';

@Component({
  selector: 'dark-light-toggle',
  templateUrl: './dark-light-toggle.component.html',
  styleUrl: './dark-light-toggle.component.scss',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatSlideToggleModule,
    MatIconModule,
    MatButtonToggleModule, 
  ]
})
export class DarkLightToggleComponent {
  private readonly darkLightService = inject(DarkLightColorSchemeService);
  darkLight = this.darkLightService.darkLight;
  //toggle = false;

  setDarkLight(pref: DarkLight): void {
    this.darkLightService.setDarkLight(pref);
  }
}
/*
    <button mat-icon-button (click)="toggleTheme()">
      <mat-icon>{{ isDarkTheme() ? 'light_mode' : 'bedtime' }}</mat-icon>
    </button>

const darkClassName = 'darkMode';
const lightClassName = '';

  protected toggleTheme(): void {
    if (this.className === darkClassName) {
      this.overlay.getContainerElement().classList.remove(darkClassName);
      this.className = lightClassName;
    } else {
      this.overlay.getContainerElement().classList.add(darkClassName);
      this.className = darkClassName;
    }
  }

*/