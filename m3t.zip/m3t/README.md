# MyAppM33

[https://angular-material.dev/articles/angular-material-3](https://angular-material.dev/articles/angular-material-3)


ng generate @angular/material:navigation layout
ng generate @angular/material:dashboard dashboard
ng generate @angular/material:address-form address-form
ng generate @angular/material:table table
ng generate @angular/material:tree tree
ng generate @angular/cdk:drag-drop drag-drop

ng generate @angular/material:m3-theme

What HEX color should be used to generate the M3 theme? It will represent your primary color palette. (ex. #ffffff)	 #6750A4
What HEX color should be used represent the secondary color palette? (Leave blank to use generated colors from Material)	Leave blank
What HEX color should be used represent the tertiary color palette? (Leave blank to use generated colors from Material)	Leave blank
What HEX color should be used represent the neutral color palette? (Leave blank to use generated colors from Material)	Leave blank
What is the directory you want to place the generated theme file in? (Enter the relative path such as 'src/app/styles/' or leave blank to generate at your project root)	Leave blank
Do you want to use system-level variables in the theme? System-level variables make dynamic theming easier through CSS custom properties, but increase the bundle size.	No
Choose light, dark, or both to generate the corresponding themes	both


[https://angular-material.dev/articles/modify-angular-material-19-theme-with-scss-css](https://angular-material.dev/articles/modify-angular-material-19-theme-with-scss-css)


ng generate @angular/material:navigation navigation
ng generate @angular/material:dashboard dashboard
ng generate @angular/material:address-form address-form
ng generate @angular/material:table table

ng generate @angular/material:theme-color

1	What HEX color should be used to generate the M3 theme? It will represent your primary color palette.	 #6750a4
2	What HEX color should be used represent the secondary color palette?	Leave blank
3	What HEX color should be used represent the tertiary color palette?	Leave blank
4	What HEX color should be used represent the neutral color palette?	Leave blank
5	What is the directory you want to place the generated theme file in?	src/styles/


[https://medium.com/@sehban.alam/advanced-theme-management-in-angular-create-custom-angular-material-themes-a8371f0b68dd](https://medium.com/@sehban.alam/advanced-theme-management-in-angular-create-custom-angular-material-themes-a8371f0b68dd)


```text
src/
??? app/
??? assets/
??? styles/
?   ??? themes/
?   ?   ??? light-theme.scss
?   ?   ??? dark-theme.scss
?   ?   ??? typography.scss
??? index.html
??? angular.json
```

`src/styles/themes/light-theme.scss`

```scss
@use '@angular/material' as mat;

$custom-primary: mat.define-palette(mat.$cyan-palette, 500, 300, 700);
$custom-accent: mat.define-palette(mat.$amber-palette, A200, A100, A400);
$custom-warn: mat.define-palette(mat.$red-palette);
$custom-theme: mat.define-theme((
  color: (
    primary: $custom-primary,
    accent: $custom-accent,
    warn: $custom-warn,
    theme-type: light
  ),
  typography: mat.define-typography-config(),
  density: 0
));
// Apply to all components
@include mat.all-component-themes($custom-theme);
```

`src/styles/themes/dark-theme.scss`

```scss
@use '@angular/material' as mat;

$dark-primary: mat.define-palette(mat.$blue-palette, 800, 500, 900);
$dark-accent: mat.define-palette(mat.$pink-palette, A700, A400, A900);

$dark-theme: mat.define-theme((
  color: (
    primary: $dark-primary,
    accent: $dark-accent,
    warn: $custom-warn,
    theme-type: dark
  ),
  typography: mat.define-typography-config(),
  density: -1
));
@include mat.all-component-themes($dark-theme);
```

`angular.json`

```json
"styles": [
  "src/styles.scss",
  "src/styles/themes/light-theme.scss",
 "src/styles/themes/dark-theme.scss"
]
```

switch dynamically

```scaa
:root {
  @include mat.all-component-colors($light-theme);
}

@media (prefers-color-scheme: dark) {
  @include mat.all-component-colors($dark-theme);
}
```


`src/styles/themes/typography.scss`

```scss
@use '@angular/material' as mat;

$custom-typography: mat.define-typography-config(
  font-family: 'Roboto, Arial, sans-serif',
  headline-1: (
    font-size: 48px,
    font-weight: 400,
    line-height: 56px
  ),
  body-1: (
    font-size: 16px,
    font-weight: 300,
    line-height: 24px
  )
);

@include mat.typography-hierarchy($custom-typography);
```

Apply themes to specific components

```scss
.my-custom-card {
  @include mat.card-theme($custom-theme);
}
```


[https://themes.angular-material.dev/](https://themes.angular-material.dev/)

[https://material-foundation.github.io/material-theme-builder/](https://material-foundation.github.io/material-theme-builder/)

#E9A297
#A38B88
#9E8F71
#968F8E
