import {isPlatformBrowser} from '@angular/common';
import {Injectable, PLATFORM_ID, inject, signal, DOCUMENT} from '@angular/core';
import {Subject} from 'rxjs';

import {LOCAL_STORAGE} from './local-storage';

/*
Insert the following code into the index.html file:

<!-- We set all theme classes to allow critters to inline the theme styles and prevent flickering. -->
<html lang="en" class="darkMode lightMode">
<head>
    <script>
      // This logic must execute early, so that we set the necessary CSS classes
      // to the document node and avoid unstyled content from appearing on the page.

      // 1. Read dark/light theme preferences stored in localStorage.
      let darkLight =
        localStorage.getItem('darkLightPreference') ?? undefined;

      // 2. In case not found in locat storage, read from device preferences.
      if (darkLight === undefined) {
        darkLight = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
          ? 'dark'
          : 'light';
      }
      
      const documentClassList = this.document.documentElement.classList;

      // Clearing classes before setting them.
      this.document.documentElement.className = '';
      documentClassList.add(darkLight === 'dark' ? 'darkMode' : 'lightMode');
    </script>
*/

// Keep these constants in sync with the code in index.html shown above.
export const DARK_LIGHT_PREFERENCE_LOCAL_STORAGE_KEY = 'darkLightPreference';
export const DARK_MODE_CLASS_NAME = 'darkMode';
export const LIGHT_MODE_CLASS_NAME = 'lightMode';
export const PREFERS_COLOR_SCHEME_DARK = '(prefers-color-scheme: dark)';

export type DarkLight = 'dark' | 'light';

@Injectable({
  providedIn: 'root',
})
export class DarkLightColorSchemeService {
  private readonly document = inject(DOCUMENT);
  private readonly localStorage = inject(LOCAL_STORAGE);
  private readonly platformId = inject(PLATFORM_ID);

  readonly darkLight = signal<DarkLight>(this.getPreference());

  // Zoneless - it's required to notify that theme was changed.
  // It could be removed when signal-based components will be available.
  readonly darkLightChanged$ = new Subject<void>();

  constructor() {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    const pref = this.getPreference();
    this.darkLight.set(pref);
    this.setBodyClass(pref);

    this.watchDevicePreference();
  }

  setDarkLight(darkLight: DarkLight): void {
    this.darkLight.set(darkLight);
    this.setLocalStorage();
    this.setBodyClass(darkLight);
  }

  // Set class on the body element.
  private setBodyClass(darkLight: DarkLight): void {
    const documentClassList = this.document.documentElement.classList;

    if (darkLight === 'dark') {
      documentClassList.add(DARK_MODE_CLASS_NAME);
      documentClassList.remove(LIGHT_MODE_CLASS_NAME);
    } else {
      documentClassList.add(LIGHT_MODE_CLASS_NAME);
      documentClassList.remove(DARK_MODE_CLASS_NAME);
    }

    this.darkLightChanged$.next();
  }

  // 1. Read preferences stored in local storage.
  // 2. If not found in locat storage, read from device preferences.
  private getPreference(): DarkLight {
    return this.getLocalStorage() ?? preferredScheme();
  }

  private getLocalStorage(): DarkLight | undefined {
    return this.localStorage?.getItem(DARK_LIGHT_PREFERENCE_LOCAL_STORAGE_KEY) as DarkLight | undefined;
  }

  private setLocalStorage(): void {
    this.localStorage?.setItem(DARK_LIGHT_PREFERENCE_LOCAL_STORAGE_KEY, this.darkLight()!);
  }

  private watchDevicePreference(): void {
    window.matchMedia(PREFERS_COLOR_SCHEME_DARK).addEventListener('change', (event) => {
      const pref = event.matches ? 'dark' : 'light';
      this.darkLight.set(pref);
      this.setBodyClass(pref);
    });
  }
}

function preferredScheme(): DarkLight {
  return window.matchMedia(PREFERS_COLOR_SCHEME_DARK).matches ? 'dark' : 'light';
}
