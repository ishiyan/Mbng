import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'theme',
  },
  {
    path: 'theme',
    loadComponent: () =>
      import('./ang-comp/theme/theme-demo').then(
        (c) => c.ThemeDemo
      ),
      title: 'Theme'
  },
  {
    path: 'typography',
    loadComponent: () =>
      import('./ang-comp/typography/typography-demo').then(
        (c) => c.TypographyDemo
      ),
      title: 'Typography'
  },
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./dashboard/dashboard.component').then(
        (c) => c.DashboardComponent
      ),
      title: 'Dashboard'
  },
  {
    path: 'address',
    loadComponent: () =>
      import('./address-form/address-form.component').then(
        (c) => c.AddressFormComponent
      ),
      title: 'Address'
  },
  {
    path: 'table',
    loadComponent: () =>
      import('./table/table.component').then(
        (c) => c.TableComponent
      ),
      title: 'Table'
  },
  {
    path: 'tree',
    loadComponent: () =>
      import('./tree/tree.component').then(
        (c) => c.TreeComponent
      ),
      title: 'Tree'
  },
  {
    path: 'drag-drop',
    loadComponent: () =>
      import('./drag-drop/drag-drop.component').then(
        (c) => c.DragDropComponent
      ),
      title: 'Drag-Drop'
  },
  {
    path: 'button',
    loadComponent: () =>
      import('./ang-comp/button/button-demo').then(
        (c) => c.ButtonDemo
      ),
      title: 'Button'
  },
  {
    path: 'button-toggle',
    loadComponent: () =>
      import('./ang-comp/button-toggle/button-toggle-demo').then(
        (c) => c.ButtonToggleDemo
      ),
      title: 'ButtonToggle'
  },
  {
    path: 'chips',
    loadComponent: () =>
      import('./ang-comp/chips/chips-demo').then(
        (c) => c.ChipsDemo
      ),
      title: 'Chips'
  },
  {
    path: 'checkbox',
    loadComponent: () =>
      import('./ang-comp/checkbox/checkbox-demo').then(
        (c) => c.CheckboxDemo
      ),
      title: 'Checkbox'
  },
  {
    path: 'radio',
    loadComponent: () =>
      import('./ang-comp/radio/radio-demo').then(
        (c) => c.RadioDemo
      ),
      title: 'Radio'
  },
  {
    path: 'slide-toggle',
    loadComponent: () =>
      import('./ang-comp/slide-toggle/slide-toggle-demo').then(
        (c) => c.SlideToggleDemo
      ),
      title: 'Slide toggle'
  },
  {
    path: 'elevation',
    loadComponent: () =>
      import('./ang-comp/elevation-overview/elevation-overview-example').then(
        (c) => c.ElevationOverviewExample
      ),
      title: 'Elevation'
  },
  /*{
    path: 'ripple',
    loadComponent: () =>
      import('./ang-comp/ripple/ripple-demo').then(
        (c) => c.RippleDemo
      ),
      title: 'Ripple'
  },*/
  {
    path: 'icon',
    loadComponent: () =>
      import('./ang-comp/icon/icon-demo').then(
        (c) => c.IconDemo
      ),
      title: 'Icon'
  },
  {
    path: 'badge',
    loadComponent: () =>
      import('./ang-comp/badge/badge-demo').then(
        (c) => c.BadgeDemo
      ),
      title: 'Badge'
  },
  {
    path: 'baseline',
    loadComponent: () =>
      import('./ang-comp/baseline/baseline-demo').then(
        (c) => c.BaselineDemo
      ),
      title: 'Baseline'
  },
  {
    path: 'input',
    loadComponent: () =>
      import('./ang-comp/input/input-demo').then(
        (c) => c.InputDemo
      ),
      title: 'Input'
  },
  {
    path: 'input-modality',
    loadComponent: () =>
      import('./ang-comp/input-modality/input-modality-detector-demo').then(
        (c) => c.InputModalityDetectorDemo
      ),
      title: 'Input modality'
  },
  {
    path: 'autocomplete',
    loadComponent: () =>
      import('./ang-comp/autocomplete/autocomplete-demo').then(
        (c) => c.AutocompleteDemo
      ),
      title: 'Autocomplete'
  },
  {
    path: 'focus-origin',
    loadComponent: () =>
      import('./ang-comp/focus-origin/focus-origin-demo').then(
        (c) => c.FocusOriginDemo
      ),
      title: 'Focus origin'
  },
  {
    path: 'focus-trap',
    loadComponent: () =>
      import('./ang-comp/focus-trap/focus-trap-demo').then(
        (c) => c.FocusTrapDemo
      ),
      title: 'Focus trap'
  },
  {
    path: 'datepicker',
    loadComponent: () =>
      import('./ang-comp/datepicker/datepicker-demo').then(
        (c) => c.DatepickerDemo
      ),
      title: 'Datepicker'
  },
  {
    path: 'timepicker',
    loadComponent: () =>
      import('./ang-comp/timepicker/timepicker-demo').then(
        (c) => c.TimepickerDemo
      ),
      title: 'Timepicker'
  },
  {
    path: 'tooltip',
    loadComponent: () =>
      import('./ang-comp/tooltip/tooltip-demo').then(
        (c) => c.TooltipDemo
      ),
      title: 'Tooltip'
  },
  {
    path: 'expansion',
    loadComponent: () =>
      import('./ang-comp/expansion/expansion-demo').then(
        (c) => c.ExpansionDemo
      ),
      title: 'Expansion'
  },
  {
    path: 'select',
    loadComponent: () =>
      import('./ang-comp/select/select-demo').then(
        (c) => c.SelectDemo
      ),
      title: 'Select'
  },
  {
    path: 'list',
    loadComponent: () =>
      import('./ang-comp/list/list-demo').then(
        (c) => c.ListDemo
      ),
      title: 'List'
  },
  {
    path: 'cdk-listbox',
    loadComponent: () =>
      import('./ang-comp/cdk-listbox/cdk-listbox-demo').then(
        (c) => c.CdkListboxDemo
      ),
      title: 'CDK listbox'
  },
  {
    path: 'grid-list',
    loadComponent: () =>
      import('./ang-comp/grid-list/grid-list-demo').then(
        (c) => c.GridListDemo
      ),
      title: 'Gridlist'
  },
  {
    path: 'slider',
    loadComponent: () =>
      import('./ang-comp/slider/slider-demo').then(
        (c) => c.SliderDemo
      ),
      title: 'Slider'
  },
  {
    path: 'progress-bar',
    loadComponent: () =>
      import('./ang-comp/progress-bar/progress-bar-demo').then(
        (c) => c.ProgressBarDemo
      ),
      title: 'Progress bar'
  },
  {
    path: 'progress-spinner',
    loadComponent: () =>
      import('./ang-comp/progress-spinner/progress-spinner-demo').then(
        (c) => c.ProgressSpinnerDemo
      ),
      title: 'Progress spinner'
  },
  {
    path: 'snack-bar',
    loadComponent: () =>
      import('./ang-comp/snack-bar/snack-bar-demo').then(
        (c) => c.SnackBarDemo
      ),
      title: 'Snack bar'
  },
  {
    path: 'bottom-sheet',
    loadComponent: () =>
      import('./ang-comp/bottom-sheet/bottom-sheet-demo').then(
        (c) => c.BottomSheetDemo
      ),
      title: 'Bottom sheet'
  },
  {
    path: 'dialog',
    loadComponent: () =>
      import('./ang-comp/dialog/dialog-demo').then(
        (c) => c.DialogDemo
      ),
      title: 'Dialog'
  },
  {
    path: 'cdk-dialog',
    loadComponent: () =>
      import('./ang-comp/cdk-dialog/dialog-demo').then(
        (c) => c.DialogDemo
      ),
      title: 'CDK dialog'
  },
  {
    path: 'connected-overlay',
    loadComponent: () =>
      import('./ang-comp/connected-overlay/connected-overlay-demo').then(
        (c) => c.ConnectedOverlayDemo
      ),
      title: 'CDK connected overlay'
  },
  {
    path: 'portal',
    loadComponent: () =>
      import('./ang-comp/portal/portal-demo').then(
        (c) => c.PortalDemo
      ),
      title: 'Portal'
  },
  {
    path: 'drawer',
    loadComponent: () =>
      import('./ang-comp/drawer/drawer-demo').then(
        (c) => c.DrawerDemo
      ),
      title: 'Drawer'
  },
  {
    path: 'sidenav',
    loadComponent: () =>
      import('./ang-comp/sidenav/sidenav-demo').then(
        (c) => c.SidenavDemo
      ),
      title: 'Sidenav'
  },
  {
    path: 'toolbar',
    loadComponent: () =>
      import('./ang-comp/toolbar/toolbar-demo').then(
        (c) => c.ToolbarDemo
      ),
      title: 'Toolbar'
  },
  {
    path: 'menu',
    loadComponent: () =>
      import('./ang-comp/menu/menu-demo').then(
        (c) => c.MenuDemo
      ),
      title: 'Menu'
  },
  {
    path: 'cdk-menu',
    loadComponent: () =>
      import('./ang-comp/cdk-menu/cdk-menu-demo').then(
        (c) => c.CdkMenuDemo
      ),
      title: 'CDK menu'
  },
  {
    path: 'tabs',
    loadComponent: () =>
      import('./ang-comp/tabs/tabs-demo').then(
        (c) => c.TabsDemo
      ),
      title: 'Tabs'
  },
  {
    path: 'stepper',
    loadComponent: () =>
      import('./ang-comp/stepper/stepper-demo').then(
        (c) => c.StepperDemo
      ),
      title: 'Stepper'
  },
  {
    path: 'card',
    loadComponent: () =>
      import('./ang-comp/card/card-demo').then(
        (c) => c.CardDemo
      ),
      title: 'Card'
  },
  {
    path: 'paginator',
    loadComponent: () =>
      import('./ang-comp/paginator/paginator-demo').then(
        (c) => c.PaginatorDemo
      ),
      title: 'Paginator'
  },
  {
    path: 'table2',
    loadComponent: () =>
      import('./ang-comp/table/table-demo').then(
        (c) => c.TableDemo
      ),
      title: 'Table'
  },
  {
    path: 'tree2',
    loadComponent: () =>
      import('./ang-comp/tree/tree-demo').then(
        (c) => c.TreeDemo
      ),
      title: 'Tree'
  },
  {
    path: 'clipboard',
    loadComponent: () =>
      import('./ang-comp/clipboard/clipboard-demo').then(
        (c) => c.ClipboardDemo
      ),
      title: 'Clipboard'
  },
  {
    path: 'dragdrop2',
    loadComponent: () =>
      import('./ang-comp/drag-drop/drag-drop-demo').then(
        (c) => c.DragAndDropDemo
      ),
      title: 'Drag-drop'
  },
  {
    path: 'live-announcer',
    loadComponent: () =>
      import('./ang-comp/live-announcer/live-announcer-demo').then(
        (c) => c.LiveAnnouncerDemo
      ),
      title: 'Live announcer'
  },
  {
    path: 'performance',
    loadComponent: () =>
      import('./ang-comp/performance/performance-demo').then(
        (c) => c.PerformanceDemo
      ),
      title: 'Performance'
  },
  {
    path: 'platform',
    loadComponent: () =>
      import('./ang-comp/platform/platform-demo').then(
        (c) => c.PlatformDemo
      ),
      title: 'Platform'
  },
  {
    path: 'screen-type',
    loadComponent: () =>
      import('./ang-comp/screen-type/screen-type-demo').then(
        (c) => c.ScreenTypeDemo
      ),
      title: 'Screen type'
  },
  {
    path: 'layout',
    loadComponent: () =>
      import('./ang-comp/layout/layout-demo').then(
        (c) => c.LayoutDemo
      ),
      title: 'Layout'
  },
];
