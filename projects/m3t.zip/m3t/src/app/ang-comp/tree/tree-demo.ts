/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import {CdkTreeModule} from '@angular/cdk/tree';
import {ChangeDetectionStrategy, Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatTreeModule} from '@angular/material/tree';

import {CdkTreeFlatExample} from './cdk-tree-flat/cdk-tree-flat-example';
import {CdkTreeNestedExample} from './cdk-tree-nested/cdk-tree-nested-example';
import {CdkTreeFlatLevelAccessorExample} from './cdk-tree-flat-level-accessor/cdk-tree-flat-level-accessor-example';
import {CdkTreeNestedLevelAccessorExample} from './cdk-tree-nested-level-accessor/cdk-tree-nested-level-accessor-example';
import {CdkTreeNestedChildrenAccessorExample} from './cdk-tree-nested-children-accessor/cdk-tree-nested-children-accessor-example';
import {CdkTreeFlatChildrenAccessorExample} from './cdk-tree-flat-children-accessor/cdk-tree-flat-children-accessor-example';
import {CdkTreeComplexExample} from './cdk-tree-complex/cdk-tree-complex-example';
import {CdkTreeCustomKeyManagerExample} from './cdk-tree-custom-key-manager/cdk-tree-custom-key-manager-example';

import {TreeDynamicExample} from './tree-dynamic/tree-dynamic-example';
import {TreeFlatOverviewExample} from './tree-flat-overview/tree-flat-overview-example';
import {TreeLegacyKeyboardInterfaceExample} from './tree-legacy-keyboard-interface/tree-legacy-keyboard-interface-example';
import {TreeLoadmoreExample} from './tree-loadmore/tree-loadmore-example';
import {TreeNestedOverviewExample} from './tree-nested-overview/tree-nested-overview-example';
import {TreeNestedChildAccessorOverviewExample} from './tree-nested-child-accessor-overview/tree-nested-child-accessor-overview-example';
import {TreeFlatChildAccessorOverviewExample} from './tree-flat-child-accessor-overview/tree-flat-child-accessor-overview-example';

@Component({
  selector: 'tree-demo',
  templateUrl: 'tree-demo.html',
  styleUrl: 'tree-demo.scss',
  imports: [
    CdkTreeModule,
    CdkTreeCustomKeyManagerExample,
    CdkTreeFlatExample,
    CdkTreeNestedExample,
    CdkTreeFlatChildrenAccessorExample,
    CdkTreeFlatLevelAccessorExample,
    CdkTreeNestedChildrenAccessorExample,
    CdkTreeNestedLevelAccessorExample,
    CdkTreeComplexExample,
    FormsModule,
    TreeDynamicExample,
    TreeFlatChildAccessorOverviewExample,
    TreeFlatOverviewExample,
    TreeLegacyKeyboardInterfaceExample,
    TreeLoadmoreExample,
    TreeNestedChildAccessorOverviewExample,
    TreeNestedOverviewExample,
    MatButtonModule,
    MatExpansionModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatTreeModule,
    MatProgressBarModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TreeDemo {}
