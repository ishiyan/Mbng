/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
import {ChangeDetectionStrategy, Component} from '@angular/core';

import {CdkTableBasicExample} from './cdk-table-basic/cdk-table-basic-example';
import {CdkTableFixedLayoutExample} from './cdk-table-fixed-layout/cdk-table-fixed-layout-example';
import {CdkTableFlexBasicExample} from './cdk-table-flex-basic/cdk-table-flex-basic-example';
import {CdkTableRecycleRowsExample} from './cdk-table-recycle-rows/cdk-table-recycle-rows-example';

import {TableBasicExample} from './table-basic/table-basic-example';
import {TableDynamicColumnsExample} from './table-dynamic-columns/table-dynamic-columns-example';
import {TableExpandableRowsExample} from './table-expandable-rows/table-expandable-rows-example';
import {TableFilteringExample} from './table-filtering/table-filtering-example';
import {TableFlexBasicExample} from './table-flex-basic/table-flex-basic-example';
import {TableFlexLargeRowExample} from './table-flex-large-row/table-flex-large-row-example';
import {TableFooterRowExample} from './table-footer-row/table-footer-row-example';
import {TableHttpExample} from './table-http/table-http-example';
import {TableMultipleHeaderFooterExample} from './table-multiple-header-footer/table-multiple-header-footer-example';
import {TableMultipleRowTemplateExample} from './table-multiple-row-template/table-multiple-row-template-example';
import {TableOverviewExample} from './table-overview/table-overview-example';
import {TablePaginationExample} from './table-pagination/table-pagination-example';
import {TableRecycleRowsExample} from './table-recycle-rows/table-recycle-rows-example';
import {TableReorderableExample} from './table-reorderable/table-reorderable-example';
import {TableRowContextExample} from './table-row-context/table-row-context-example';
import {TableSelectionExample} from './table-selection/table-selection-example';
import {TableSortingExample} from './table-sorting/table-sorting-example';
import {TableStickyColumnsExample} from './table-sticky-columns/table-sticky-columns-example';
import {TableStickyComplexExample} from './table-sticky-complex/table-sticky-complex-example';
import {TableStickyComplexFlexExample} from './table-sticky-complex-flex/table-sticky-complex-flex-example';
import {TableStickyFooterExample} from './table-sticky-footer/table-sticky-footer-example';
import {TableStickyHeaderExample} from './table-sticky-header/table-sticky-header-example';
import {TableTextColumnAdvancedExample} from './table-text-column-advanced/table-text-column-advanced-example';
import {TableTextColumnExample} from './table-text-column/table-text-column-example';
import {TableWrappedExample} from './table-wrapped/table-wrapped-example';

@Component({
  templateUrl: './table-demo.html',
  imports: [
    CdkTableFlexBasicExample,
    CdkTableBasicExample,
    CdkTableFixedLayoutExample,
    CdkTableRecycleRowsExample,
    TableFlexBasicExample,
    TableBasicExample,
    TableDynamicColumnsExample,
    TableExpandableRowsExample,
    TableFilteringExample,
    TableFooterRowExample,
    TableHttpExample,
    TableMultipleHeaderFooterExample,
    TableMultipleRowTemplateExample,
    TableOverviewExample,
    TablePaginationExample,
    TableRowContextExample,
    TableSelectionExample,
    TableSortingExample,
    TableStickyColumnsExample,
    TableStickyComplexFlexExample,
    TableStickyComplexExample,
    TableStickyFooterExample,
    TableStickyHeaderExample,
    TableTextColumnAdvancedExample,
    TableTextColumnExample,
    TableWrappedExample,
    TableReorderableExample,
    TableRecycleRowsExample,
    TableFlexLargeRowExample,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TableDemo {}
